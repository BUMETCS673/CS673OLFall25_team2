package com.cs673.careerforge.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

/**
 * Unit tests for ApplicationTracking com.cs673.careerforge.entity.
 */
@DisplayName("ApplicationTracking Entity Tests")
class ApplicationTrackingTest {
    
    private ApplicationTracking application;
    private User applicant;
    private Job job;
    
    @BeforeEach
    void setUp() {
        applicant = new User();
        applicant.setId(1L);
        applicant.setUsername("applicant");
        applicant.setUserType(UserType.EMPLOYEE);
        
        User employer = new User();
        employer.setId(2L);
        employer.setUsername("employer");
        employer.setUserType(UserType.EMPLOYER);
        
        job = new Job();
        job.setId(1L);
        job.setTitle("Software Engineer");
        job.setPostedBy(employer);
        
        application = new ApplicationTracking();
        application.setApplicant(applicant);
        application.setJob(job);
        application.setApplicationStatus(ApplicationStatus.APPLIED);
    }
    
    @Test
    @DisplayName("Should create application with valid data")
    void shouldCreateApplicationWithValidData() {
        assertNotNull(application);
        assertEquals(applicant, application.getApplicant());
        assertEquals(job, application.getJob());
        assertEquals(ApplicationStatus.APPLIED, application.getApplicationStatus());
        assertNotNull(application.getAppliedDate());
        assertNotNull(application.getLastUpdated());
    }
    
    @Test
    @DisplayName("Should create application with constructor")
    void shouldCreateApplicationWithConstructor() {
        ApplicationTracking newApp = new ApplicationTracking(applicant, job);
        
        assertEquals(applicant, newApp.getApplicant());
        assertEquals(job, newApp.getJob());
        assertEquals(ApplicationStatus.APPLIED, newApp.getApplicationStatus());
        assertNotNull(newApp.getAppliedDate());
        assertNotNull(newApp.getLastUpdated());
    }
    
    @Test
    @DisplayName("Should create application with constructor and status")
    void shouldCreateApplicationWithConstructorAndStatus() {
        ApplicationTracking newApp = new ApplicationTracking(applicant, job, ApplicationStatus.UNDER_REVIEW);
        
        assertEquals(applicant, newApp.getApplicant());
        assertEquals(job, newApp.getJob());
        assertEquals(ApplicationStatus.UNDER_REVIEW, newApp.getApplicationStatus());
    }
    
//    @Test
//    @DisplayName("Should check resume presence correctly")
//    void shouldCheckResumePresenceCorrectly() {
//        assertFalse(application.hasResume());
//
//        application.setResumePath("/path/to/resume.pdf");
//        assertTrue(application.hasResume());
//
//        application.setResumePath("");
//        assertFalse(application.hasResume());
//
//        application.setResumePath("   ");
//        assertFalse(application.hasResume());
//    }
    
    @Test
    @DisplayName("Should check cover letter presence correctly")
    void shouldCheckCoverLetterPresenceCorrectly() {
        assertFalse(application.hasCoverLetter());
        
        application.setCoverLetter("This is my cover letter");
        assertTrue(application.hasCoverLetter());
        
        application.setCoverLetter("");
        assertFalse(application.hasCoverLetter());
        
        application.setCoverLetter("   ");
        assertFalse(application.hasCoverLetter());
    }
    
    @Test
    @DisplayName("Should check notes presence correctly")
    void shouldCheckNotesPresenceCorrectly() {
        assertFalse(application.hasNotes());
        
        application.setNotes("This is a note");
        assertTrue(application.hasNotes());
        
        application.setNotes("");
        assertFalse(application.hasNotes());
        
        application.setNotes("   ");
        assertFalse(application.hasNotes());
    }
    
    @Test
    @DisplayName("Should check interview scheduled correctly")
    void shouldCheckInterviewScheduledCorrectly() {
        assertFalse(application.isInterviewScheduled());
        
        application.setInterviewDate(LocalDateTime.now().plusDays(1));
        assertTrue(application.isInterviewScheduled());
    }
    
    @Test
    @DisplayName("Should check follow-up scheduled correctly")
    void shouldCheckFollowUpScheduledCorrectly() {
        assertFalse(application.isFollowUpScheduled());
        
        application.setFollowUpDate(LocalDateTime.now().plusDays(1));
        assertTrue(application.isFollowUpScheduled());
    }
    
    @Test
    @DisplayName("Should check if application is active correctly")
    void shouldCheckIfApplicationIsActiveCorrectly() {
        // Applied status should be active
        assertTrue(application.isActive());
        
        // Under review should be active
        application.setApplicationStatus(ApplicationStatus.UNDER_REVIEW);
        assertTrue(application.isActive());
        
        // Interview scheduled should be active
        application.setApplicationStatus(ApplicationStatus.INTERVIEW_SCHEDULED);
        assertTrue(application.isActive());
        
        // Rejected should not be active
        application.setApplicationStatus(ApplicationStatus.REJECTED);
        assertFalse(application.isActive());
        
        // Accepted should not be active
        application.setApplicationStatus(ApplicationStatus.ACCEPTED);
        assertFalse(application.isActive());
        
        // Withdrawn should not be active
        application.setApplicationStatus(ApplicationStatus.WITHDRAWN);
        assertFalse(application.isActive());
    }
    
    @Test
    @DisplayName("Should check if application is completed correctly")
    void shouldCheckIfApplicationIsCompletedCorrectly() {
        // Applied status should not be completed
        assertFalse(application.isCompleted());
        
        // Under review should not be completed
        application.setApplicationStatus(ApplicationStatus.UNDER_REVIEW);
        assertFalse(application.isCompleted());
        
        // Interview scheduled should not be completed
        application.setApplicationStatus(ApplicationStatus.INTERVIEW_SCHEDULED);
        assertFalse(application.isCompleted());
        
        // Rejected should be completed
        application.setApplicationStatus(ApplicationStatus.REJECTED);
        assertTrue(application.isCompleted());
        
        // Accepted should be completed
        application.setApplicationStatus(ApplicationStatus.ACCEPTED);
        assertTrue(application.isCompleted());
        
        // Withdrawn should not be completed
        application.setApplicationStatus(ApplicationStatus.WITHDRAWN);
        assertFalse(application.isCompleted());
    }
    
    @Test
    @DisplayName("Should calculate days since applied correctly")
    void shouldCalculateDaysSinceAppliedCorrectly() {
        // Set applied date to 5 days ago
        LocalDateTime fiveDaysAgo = LocalDateTime.now().minusDays(5);
        application.setAppliedDate(fiveDaysAgo);
        
        long daysSinceApplied = application.getDaysSinceApplied();
        assertTrue(daysSinceApplied >= 4 && daysSinceApplied <= 6); // Allow for some time difference
    }
    
    @Test
    @DisplayName("Should validate interview date correctly")
    void shouldValidateInterviewDateCorrectly() {
        // No interview date should be valid
        assertTrue(application.isValidInterviewDate());
        
        // Future interview date should be valid
        application.setInterviewDate(LocalDateTime.now().plusDays(1));
        assertTrue(application.isValidInterviewDate());
        
        // Interview date before applied date should be invalid
        LocalDateTime pastDate = application.getAppliedDate().minusDays(1);
        application.setInterviewDate(pastDate);
        assertFalse(application.isValidInterviewDate());
    }
    
    @Test
    @DisplayName("Should validate follow-up date correctly")
    void shouldValidateFollowUpDateCorrectly() {
        // No follow-up date should be valid
        assertTrue(application.isValidFollowUpDate());
        
        // Future follow-up date should be valid
        application.setFollowUpDate(LocalDateTime.now().plusDays(1));
        assertTrue(application.isValidFollowUpDate());
        
        // Follow-up date before applied date should be invalid
        LocalDateTime pastDate = application.getAppliedDate().minusDays(1);
        application.setFollowUpDate(pastDate);
        assertFalse(application.isValidFollowUpDate());
    }
    
    @Test
    @DisplayName("Should set timestamps on creation")
    void shouldSetTimestampsOnCreation() {
        ApplicationTracking newApp = new ApplicationTracking(applicant, job);
        
        assertNotNull(newApp.getAppliedDate());
        assertNotNull(newApp.getLastUpdated());
        assertTrue(newApp.getAppliedDate().isBefore(LocalDateTime.now().plusSeconds(1)));
        assertTrue(newApp.getLastUpdated().isBefore(LocalDateTime.now().plusSeconds(1)));
    }
    
    @Test
    @DisplayName("Should update timestamp on update")
    void shouldUpdateTimestampOnUpdate() {
        LocalDateTime originalUpdatedAt = application.getLastUpdated();
        
        // Simulate update
        application.setNotes("Updated notes");
        application.onUpdate();
        
        assertTrue(application.getLastUpdated().isAfter(originalUpdatedAt));
    }
    
    @Test
    @DisplayName("Should handle null values gracefully")
    void shouldHandleNullValuesGracefully() {
        ApplicationTracking nullApp = new ApplicationTracking();
        
        assertNull(nullApp.getApplicant());
        assertNull(nullApp.getJob());
        assertNull(nullApp.getApplicationStatus());
        assertNull(nullApp.getNotes());
//        assertNull(nullApp.getResumePath());
        assertNull(nullApp.getCoverLetter());
        assertNull(nullApp.getInterviewDate());
        assertNull(nullApp.getFollowUpDate());
    }
    
    @Test
    @DisplayName("Should implement equals and hashCode correctly")
    void shouldImplementEqualsAndHashCodeCorrectly() {
        ApplicationTracking app1 = new ApplicationTracking();
        app1.setId(1L);
        
        ApplicationTracking app2 = new ApplicationTracking();
        app2.setId(1L);
        
        ApplicationTracking app3 = new ApplicationTracking();
        app3.setId(2L);
        
        assertEquals(app1, app2);
        assertNotEquals(app1, app3);
        assertEquals(app1.hashCode(), app2.hashCode());
        assertNotEquals(app1.hashCode(), app3.hashCode());
    }
    
    @Test
    @DisplayName("Should return correct string representation")
    void shouldReturnCorrectStringRepresentation() {
        String appString = application.toString();
        
        assertTrue(appString.contains("applicant"));
        assertTrue(appString.contains("Software Engineer"));
        assertTrue(appString.contains("APPLIED"));
    }
}
