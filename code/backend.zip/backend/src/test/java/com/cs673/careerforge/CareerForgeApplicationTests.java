package com.cs673.careerforge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerForgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
