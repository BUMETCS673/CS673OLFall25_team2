package com.cs673.careerforge.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for LocationCoordinates embedded entity.
 */
@DisplayName("LocationCoordinates Entity Tests")
class LocationCoordinatesTest {
    
    private LocationCoordinates coordinates;
    
    @BeforeEach
    void setUp() {
        coordinates = new LocationCoordinates(37.7749, -122.4194);
    }
    
    @Test
    @DisplayName("Should create coordinates with valid data")
    void shouldCreateCoordinatesWithValidData() {
        assertNotNull(coordinates);
        assertEquals(37.7749, coordinates.getLat());
        assertEquals(-122.4194, coordinates.getLon());
    }
    
    @Test
    @DisplayName("Should create coordinates with default constructor")
    void shouldCreateCoordinatesWithDefaultConstructor() {
        LocationCoordinates defaultCoords = new LocationCoordinates();
        assertNull(defaultCoords.getLat());
        assertNull(defaultCoords.getLon());
    }
    
    @Test
    @DisplayName("Should set and get latitude correctly")
    void shouldSetAndGetLatitudeCorrectly() {
        coordinates.setLat(40.7128);
        assertEquals(40.7128, coordinates.getLat());
    }
    
    @Test
    @DisplayName("Should set and get longitude correctly")
    void shouldSetAndGetLongitudeCorrectly() {
        coordinates.setLon(-74.0060);
        assertEquals(-74.0060, coordinates.getLon());
    }
    
    @Test
    @DisplayName("Should handle null values correctly")
    void shouldHandleNullValuesCorrectly() {
        coordinates.setLat(null);
        coordinates.setLon(null);
        
        assertNull(coordinates.getLat());
        assertNull(coordinates.getLon());
    }
    
    @Test
    @DisplayName("Should implement equals correctly")
    void shouldImplementEqualsCorrectly() {
        LocationCoordinates coords1 = new LocationCoordinates(37.7749, -122.4194);
        LocationCoordinates coords2 = new LocationCoordinates(37.7749, -122.4194);
        LocationCoordinates coords3 = new LocationCoordinates(40.7128, -74.0060);
        
        assertEquals(coords1, coords2);
        assertNotEquals(coords1, coords3);
        assertNotEquals(coords1, null);
        assertNotEquals(coords1, "not coordinates");
    }
    
    @Test
    @DisplayName("Should implement hashCode correctly")
    void shouldImplementHashCodeCorrectly() {
        LocationCoordinates coords1 = new LocationCoordinates(37.7749, -122.4194);
        LocationCoordinates coords2 = new LocationCoordinates(37.7749, -122.4194);
        LocationCoordinates coords3 = new LocationCoordinates(40.7128, -74.0060);
        
        assertEquals(coords1.hashCode(), coords2.hashCode());
        assertNotEquals(coords1.hashCode(), coords3.hashCode());
    }
    
    @Test
    @DisplayName("Should return correct string representation")
    void shouldReturnCorrectStringRepresentation() {
        String coordsString = coordinates.toString();
        
        assertTrue(coordsString.contains("37.7749"));
        assertTrue(coordsString.contains("-122.4194"));
        assertTrue(coordsString.contains("LocationCoordinates"));
    }
    
    @Test
    @DisplayName("Should handle edge case coordinates")
    void shouldHandleEdgeCaseCoordinates() {
        // Test maximum latitude
        coordinates.setLat(90.0);
        assertEquals(90.0, coordinates.getLat());
        
        // Test minimum latitude
        coordinates.setLat(-90.0);
        assertEquals(-90.0, coordinates.getLat());
        
        // Test maximum longitude
        coordinates.setLon(180.0);
        assertEquals(180.0, coordinates.getLon());
        
        // Test minimum longitude
        coordinates.setLon(-180.0);
        assertEquals(-180.0, coordinates.getLon());
    }
    
    @Test
    @DisplayName("Should handle zero coordinates")
    void shouldHandleZeroCoordinates() {
        LocationCoordinates zeroCoords = new LocationCoordinates(0.0, 0.0);
        
        assertEquals(0.0, zeroCoords.getLat());
        assertEquals(0.0, zeroCoords.getLon());
    }
}
