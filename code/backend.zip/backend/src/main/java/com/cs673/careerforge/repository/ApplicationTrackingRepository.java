package com.cs673.careerforge.repository;

import com.cs673.careerforge.entity.ApplicationStatus;
import com.cs673.careerforge.entity.ApplicationTracking;
import com.cs673.careerforge.entity.Job;
import com.cs673.careerforge.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for ApplicationTracking com.cs673.careerforge.entity operations.
 */
@Repository
public interface ApplicationTrackingRepository extends JpaRepository<ApplicationTracking, Long> {
    
    /**
     * Find application by applicant and job.
     * @param applicant the applicant user
     * @param job the job
     * @return Optional containing the application if found
     */
    Optional<ApplicationTracking> findByApplicantAndJob(User applicant, Job job);
    
    /**
     * Check if application exists for applicant and job.
     * @param applicant the applicant user
     * @param job the job
     * @return true if application exists
     */
    boolean existsByApplicantAndJob(User applicant, Job job);
    
    /**
     * Find applications by applicant.
     * @param applicant the applicant user
     * @return list of applications by the applicant
     */
    List<ApplicationTracking> findByApplicant(User applicant);
    
    /**
     * Find applications by applicant with pagination.
     * @param applicant the applicant user
     * @param pageable pagination information
     * @return page of applications by the applicant
     */
    Page<ApplicationTracking> findByApplicant(User applicant, Pageable pageable);
    
    /**
     * Find applications by job.
     * @param job the job
     * @return list of applications for the job
     */
    List<ApplicationTracking> findByJob(Job job);
    
    /**
     * Find applications by job with pagination.
     * @param job the job
     * @param pageable pagination information
     * @return page of applications for the job
     */
    Page<ApplicationTracking> findByJob(Job job, Pageable pageable);
    
    /**
     * Find applications by application status.
     * @param applicationStatus the application status to filter by
     * @return list of applications with the specified status
     */
    List<ApplicationTracking> findByApplicationStatus(ApplicationStatus applicationStatus);
    
    /**
     * Find applications by applicant and status.
     * @param applicant the applicant user
     * @param applicationStatus the application status to filter by
     * @return list of applications by the applicant with the specified status
     */
    List<ApplicationTracking> findByApplicantAndApplicationStatus(User applicant, ApplicationStatus applicationStatus);
    
    /**
     * Find applications by job and status.
     * @param job the job
     * @param applicationStatus the application status to filter by
     * @return list of applications for the job with the specified status
     */
    List<ApplicationTracking> findByJobAndApplicationStatus(Job job, ApplicationStatus applicationStatus);
    
    /**
     * Find applications by applicant with pagination and status filter.
     * @param applicant the applicant user
     * @param applicationStatus the application status to filter by (optional)
     * @param pageable pagination information
     * @return page of applications by the applicant
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.applicant = :applicant AND " +
           "(:status IS NULL OR a.applicationStatus = :status)")
    Page<ApplicationTracking> findByApplicantAndStatus(@Param("applicant") User applicant,
                                                       @Param("status") ApplicationStatus applicationStatus,
                                                       Pageable pageable);
    
    /**
     * Find applications by job with pagination and status filter.
     * @param job the job
     * @param applicationStatus the application status to filter by (optional)
     * @param pageable pagination information
     * @return page of applications for the job
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.job = :job AND " +
           "(:status IS NULL OR a.applicationStatus = :status)")
    Page<ApplicationTracking> findByJobAndStatus(@Param("job") Job job,
                                                 @Param("status") ApplicationStatus applicationStatus,
                                                 Pageable pageable);
    
    /**
     * Find applications applied after a specific date.
     * @param appliedAfter the date to filter by
     * @return list of applications applied after the specified date
     */
    List<ApplicationTracking> findByAppliedDateAfter(LocalDateTime appliedAfter);
    
    /**
     * Find applications applied between two dates.
     * @param startDate the start date
     * @param endDate the end date
     * @return list of applications applied between the dates
     */
    List<ApplicationTracking> findByAppliedDateBetween(LocalDateTime startDate, LocalDateTime endDate);
    
    /**
     * Find applications with interview scheduled.
     * @return list of applications with interview scheduled
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.interviewDate IS NOT NULL")
    List<ApplicationTracking> findApplicationsWithInterviewScheduled();
    
    /**
     * Find applications with interview scheduled after a specific date.
     * @param interviewAfter the date to filter by
     * @return list of applications with interview scheduled after the specified date
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.interviewDate IS NOT NULL AND a.interviewDate > :interviewAfter")
    List<ApplicationTracking> findApplicationsWithInterviewAfter(@Param("interviewAfter") LocalDateTime interviewAfter);
    
    /**
     * Find applications with follow-up scheduled.
     * @return list of applications with follow-up scheduled
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.followUpDate IS NOT NULL")
    List<ApplicationTracking> findApplicationsWithFollowUpScheduled();
    
    /**
     * Find applications with follow-up scheduled after a specific date.
     * @param followUpAfter the date to filter by
     * @return list of applications with follow-up scheduled after the specified date
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.followUpDate IS NOT NULL AND a.followUpDate > :followUpAfter")
    List<ApplicationTracking> findApplicationsWithFollowUpAfter(@Param("followUpAfter") LocalDateTime followUpAfter);
    
    /**
     * Find applications that need follow-up (follow-up date has passed).
     * @param currentDate the current date
     * @return list of applications that need follow-up
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.followUpDate IS NOT NULL AND a.followUpDate <= :currentDate")
    List<ApplicationTracking> findApplicationsNeedingFollowUp(@Param("currentDate") LocalDateTime currentDate);
    
    /**
     * Count applications by applicant.
     * @param applicant the applicant user
     * @return number of applications by the applicant
     */
    long countByApplicant(User applicant);
    
    /**
     * Count applications by job.
     * @param job the job
     * @return number of applications for the job
     */
    long countByJob(Job job);
    
    /**
     * Count applications by status.
     * @param applicationStatus the application status to count
     * @return number of applications with the specified status
     */
    long countByApplicationStatus(ApplicationStatus applicationStatus);
    
    /**
     * Count applications by applicant and status.
     * @param applicant the applicant user
     * @param applicationStatus the application status to count
     * @return number of applications by the applicant with the specified status
     */
    long countByApplicantAndApplicationStatus(User applicant, ApplicationStatus applicationStatus);
    
    /**
     * Count applications by job and status.
     * @param job the job
     * @param applicationStatus the application status to count
     * @return number of applications for the job with the specified status
     */
    long countByJobAndApplicationStatus(Job job, ApplicationStatus applicationStatus);
    
    /**
     * Find applications with pagination and sorting.
     * @param pageable pagination and sorting information
     * @return page of applications
     */
    Page<ApplicationTracking> findAll(Pageable pageable);
    
    /**
     * Find recent applications (applied within last N days).
     * @param days number of days to look back
     * @return list of recent applications
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.appliedDate >= :cutoffDate ORDER BY a.appliedDate DESC")
    List<ApplicationTracking> findRecentApplications(@Param("cutoffDate") LocalDateTime cutoffDate);
    
    /**
     * Find applications by multiple criteria with pagination.
     * @param applicant the applicant user (optional)
     * @param job the job (optional)
     * @param applicationStatus the application status (optional)
     * @param appliedAfter the date to filter by (optional)
     * @param pageable pagination and sorting information
     * @return page of applications matching the criteria
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE " +
           "(:applicant IS NULL OR a.applicant = :applicant) AND " +
           "(:job IS NULL OR a.job = :job) AND " +
           "(:status IS NULL OR a.applicationStatus = :status) AND " +
           "(:appliedAfter IS NULL OR a.appliedDate >= :appliedAfter)")
    Page<ApplicationTracking> findByCriteria(@Param("applicant") User applicant,
                                             @Param("job") Job job,
                                             @Param("status") ApplicationStatus applicationStatus,
                                             @Param("appliedAfter") LocalDateTime appliedAfter,
                                             Pageable pageable);
    
    /**
     * Find applications with notes.
     * @return list of applications that have notes
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.notes IS NOT NULL AND a.notes != ''")
    List<ApplicationTracking> findApplicationsWithNotes();
    
//    /**
//     * Find applications with resume.
//     * @return list of applications that have resume
//     */
//    @Query("SELECT a FROM ApplicationTracking a WHERE a.resumePath IS NOT NULL AND a.resumePath != ''")
//    List<ApplicationTracking> findApplicationsWithResume();
    
    /**
     * Find applications with cover letter.
     * @return list of applications that have cover letter
     */
    @Query("SELECT a FROM ApplicationTracking a WHERE a.coverLetter IS NOT NULL AND a.coverLetter != ''")
    List<ApplicationTracking> findApplicationsWithCoverLetter();
}
