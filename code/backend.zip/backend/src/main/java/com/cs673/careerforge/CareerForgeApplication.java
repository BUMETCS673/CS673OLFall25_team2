package com.cs673.careerforge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerForgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerForgeApplication.class, args);
	}

}
