package com.cs673.careerforge.repository;

import com.cs673.careerforge.entity.User;
import com.cs673.careerforge.entity.UserType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for User com.cs673.careerforge.entity operations.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    /**
     * Find user by username.
     * @param username the username to search for
     * @return Optional containing the user if found
     */
    Optional<User> findByUsername(String username);
    
    /**
     * Find user by email.
     * @param email the email to search for
     * @return Optional containing the user if found
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Check if username exists.
     * @param username the username to check
     * @return true if username exists
     */
    boolean existsByUsername(String username);
    
    /**
     * Check if email exists.
     * @param email the email to check
     * @return true if email exists
     */
    boolean existsByEmail(String email);
    
    /**
     * Find users by user type.
     * @param userType the user type to filter by
     * @return list of users with the specified type
     */
    List<User> findByUserType(UserType userType);
    
    /**
     * Find users by user type with pagination.
     * @param userType the user type to filter by
     * @param pageable pagination information
     * @return page of users with the specified type
     */
    Page<User> findByUserType(UserType userType, Pageable pageable);
    
    /**
     * Find active users by user type.
     * @param userType the user type to filter by
     * @param isActive whether the user is active
     * @return list of active users with the specified type
     */
    List<User> findByUserTypeAndIsActive(UserType userType, Boolean isActive);
    
    /**
     * Find users by first name containing (case-insensitive).
     * @param firstName the first name to search for
     * @return list of users with matching first name
     */
    List<User> findByFirstNameContainingIgnoreCase(String firstName);
    
    /**
     * Find users by last name containing (case-insensitive).
     * @param lastName the last name to search for
     * @return list of users with matching last name
     */
    List<User> findByLastNameContainingIgnoreCase(String lastName);
    
    /**
     * Find users by full name containing (case-insensitive).
     * @param firstName the first name to search for
     * @param lastName the last name to search for
     * @return list of users with matching full name
     */
    @Query("SELECT u FROM User u WHERE LOWER(u.firstName) LIKE LOWER(CONCAT('%', :firstName, '%')) " +
           "AND LOWER(u.lastName) LIKE LOWER(CONCAT('%', :lastName, '%'))")
    List<User> findByFullNameContainingIgnoreCase(@Param("firstName") String firstName, 
                                                  @Param("lastName") String lastName);
    
    /**
     * Find users created after a specific date.
     * @param createdAfter the date to filter by
     * @return list of users created after the specified date
     */
    List<User> findByCreatedAtAfter(LocalDateTime createdAfter);
    
    /**
     * Find users created between two dates.
     * @param startDate the start date
     * @param endDate the end date
     * @return list of users created between the dates
     */
    List<User> findByCreatedAtBetween(LocalDateTime startDate, LocalDateTime endDate);
    
    /**
     * Count users by user type.
     * @param userType the user type to count
     * @return number of users with the specified type
     */
    long countByUserType(UserType userType);
    
    /**
     * Count active users by user type.
     * @param userType the user type to count
     * @param isActive whether the user is active
     * @return number of active users with the specified type
     */
    long countByUserTypeAndIsActive(UserType userType, Boolean isActive);
    
    /**
     * Find users with pagination and sorting.
     * @param pageable pagination and sorting information
     * @return page of users
     */
    Page<User> findAll(Pageable pageable);
    
    /**
     * Find active users with pagination and sorting.
     * @param isActive whether the user is active
     * @param pageable pagination and sorting information
     * @return page of active users
     */
    Page<User> findByIsActive(Boolean isActive, Pageable pageable);
    
    /**
     * Find users by multiple criteria with pagination.
     * @param userType the user type to filter by (optional)
     * @param isActive whether the user is active (optional)
     * @param searchTerm search term for first name or last name (optional)
     * @param pageable pagination and sorting information
     * @return page of users matching the criteria
     */
    @Query("SELECT u FROM User u WHERE " +
           "(:userType IS NULL OR u.userType = :userType) AND " +
           "(:isActive IS NULL OR u.isActive = :isActive) AND " +
           "(:searchTerm IS NULL OR " +
           "LOWER(u.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(u.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(u.username) LIKE LOWER(CONCAT('%', :searchTerm, '%')))")
    Page<User> findByCriteria(@Param("userType") UserType userType,
                              @Param("isActive") Boolean isActive,
                              @Param("searchTerm") String searchTerm,
                              Pageable pageable);
}
