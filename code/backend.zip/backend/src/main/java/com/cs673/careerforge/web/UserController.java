package com.cs673.careerforge.web;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.cs673.careerforge.service.UserService;

import java.net.URI;

@RestController
@RequestMapping("/users")
@Validated
public class UserController {

    private final UserService userService;

    // Prefer constructor injection
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Register a new user.
     * Expects a JSON body matching UserRegistrationRequest.
     * Returns 201 Created with the new user's data and Location header.
     */
    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(@Valid @RequestBody UserRegistrationRequest request) {
        UserResponse created = userService.register(request);

        // Build Location: /api/v1/users/register/{id} (or change to "/{id}" if you later add GET by id)
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getId())
                .toUri();

        return ResponseEntity.created(location).body(created);
    }
}
