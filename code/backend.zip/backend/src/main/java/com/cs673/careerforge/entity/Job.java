package com.cs673.careerforge.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Job com.cs673.careerforge.entity representing job postings created by employers.
 */
@Entity
@Table(name = "jobs")
public class Job {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotNull(message = "Posted by user is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "posted_by", nullable = false)
    private User postedBy;
    
    @NotBlank(message = "Job title is required")
    @Size(min = 1, max = 100, message = "Job title must be between 1 and 100 characters")
    @Column(name = "title", nullable = false, length = 100)
    private String title;
    
    @NotBlank(message = "Job description is required")
    @Size(min = 1, max = 5000, message = "Job description must be between 1 and 5000 characters")
    @Column(name = "description", nullable = false, columnDefinition = "TEXT")
    private String description;
    
    @NotBlank(message = "Company name is required")
    @Size(min = 1, max = 100, message = "Company name must be between 1 and 100 characters")
    @Column(name = "company", nullable = false, length = 100)
    private String company;
    
    @NotBlank(message = "Job location is required")
    @Size(min = 1, max = 100, message = "Job location must be between 1 and 100 characters")
    @Column(name = "location", nullable = false, length = 100)
    private String location;
    
    @NotNull(message = "Employment type is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "employment_type", nullable = false)
    private EmploymentType employmentType;
    
    @DecimalMin(value = "0.0", message = "Minimum salary must be non-negative")
    @Column(name = "salary_min", precision = 10, scale = 2)
    private BigDecimal salaryMin;
    
    @DecimalMin(value = "0.0", message = "Maximum salary must be non-negative")
    @Column(name = "salary_max", precision = 10, scale = 2)
    private BigDecimal salaryMax;
    
    @Size(max = 5000, message = "Requirements must not exceed 5000 characters")
    @Column(name = "requirements", columnDefinition = "TEXT")
    private String requirements;
    
    @Size(max = 5000, message = "Benefits must not exceed 5000 characters")
    @Column(name = "benefits", columnDefinition = "TEXT")
    private String benefits;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;
    
    @Column(name = "application_deadline")
    private LocalDateTime applicationDeadline;
    
    // New fields from JSON structure
    @Size(max = 500, message = "Job URL must not exceed 500 characters")
    @Column(name = "url", length = 500)
    private String url;
    
    @Size(max = 50, message = "Job type must not exceed 50 characters")
    @Column(name = "type", length = 50)
    private String type;
    
    @Size(max = 100, message = "Department must not exceed 100 characters")
    @Column(name = "department", length = 100)
    private String department;
    
    @Size(max = 50, message = "Seniority must not exceed 50 characters")
    @Column(name = "seniority", length = 50)
    private String seniority;
    
    @Size(max = 200, message = "Location address must not exceed 200 characters")
    @Column(name = "location_address", length = 200)
    private String locationAddress;
    
    @Embedded
    private LocationCoordinates locationCoordinates;
    
    // JPA Relationships
    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ApplicationTracking> applications;
    
    // Constructors
    public Job() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    public Job(User postedBy, String title, String description, String company, 
               String location, EmploymentType employmentType) {
        this();
        this.postedBy = postedBy;
        this.title = title;
        this.description = description;
        this.company = company;
        this.location = location;
        this.employmentType = employmentType;
    }
    
    // JPA Lifecycle callbacks
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    
    // Validation methods
    @AssertTrue(message = "Maximum salary must be greater than or equal to minimum salary")
    public boolean isValidSalaryRange() {
        if (salaryMin == null || salaryMax == null) {
            return true; // Both can be null
        }
        return salaryMax.compareTo(salaryMin) >= 0;
    }
    
    @AssertTrue(message = "Application deadline must be in the future")
    public boolean isValidApplicationDeadline() {
        if (applicationDeadline == null) {
            return true; // Deadline is optional
        }
        return applicationDeadline.isAfter(LocalDateTime.now());
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public User getPostedBy() {
        return postedBy;
    }
    
    public void setPostedBy(User postedBy) {
        this.postedBy = postedBy;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getCompany() {
        return company;
    }
    
    public void setCompany(String company) {
        this.company = company;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public EmploymentType getEmploymentType() {
        return employmentType;
    }
    
    public void setEmploymentType(EmploymentType employmentType) {
        this.employmentType = employmentType;
    }
    
    public BigDecimal getSalaryMin() {
        return salaryMin;
    }
    
    public void setSalaryMin(BigDecimal salaryMin) {
        this.salaryMin = salaryMin;
    }
    
    public BigDecimal getSalaryMax() {
        return salaryMax;
    }
    
    public void setSalaryMax(BigDecimal salaryMax) {
        this.salaryMax = salaryMax;
    }
    
    public String getRequirements() {
        return requirements;
    }
    
    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }
    
    public String getBenefits() {
        return benefits;
    }
    
    public void setBenefits(String benefits) {
        this.benefits = benefits;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public Boolean getIsActive() {
        return isActive;
    }
    
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    
    public LocalDateTime getApplicationDeadline() {
        return applicationDeadline;
    }
    
    public void setApplicationDeadline(LocalDateTime applicationDeadline) {
        this.applicationDeadline = applicationDeadline;
    }
    
    public List<ApplicationTracking> getApplications() {
        return applications;
    }
    
    public void setApplications(List<ApplicationTracking> applications) {
        this.applications = applications;
    }
    
    // New field getters and setters
    public String getUrl() {
        return url;
    }
    
    public void setUrl(String url) {
        this.url = url;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public String getSeniority() {
        return seniority;
    }
    
    public void setSeniority(String seniority) {
        this.seniority = seniority;
    }
    
    public String getLocationAddress() {
        return locationAddress;
    }
    
    public void setLocationAddress(String locationAddress) {
        this.locationAddress = locationAddress;
    }
    
    public LocationCoordinates getLocationCoordinates() {
        return locationCoordinates;
    }
    
    public void setLocationCoordinates(LocationCoordinates locationCoordinates) {
        this.locationCoordinates = locationCoordinates;
    }
    
    // Utility methods
    public String getSalaryRange() {
        if (salaryMin == null && salaryMax == null) {
            return "Salary not specified";
        } else if (salaryMin == null) {
            return "Up to $" + salaryMax;
        } else if (salaryMax == null) {
            return "From $" + salaryMin;
        } else {
            return "$" + salaryMin + " - $" + salaryMax;
        }
    }
    
    public boolean isApplicationDeadlinePassed() {
        if (applicationDeadline == null) {
            return false;
        }
        return LocalDateTime.now().isAfter(applicationDeadline);
    }
    
    public int getApplicationCount() {
        return applications != null ? applications.size() : 0;
    }
    
    @Override
    public String toString() {
        return "Job{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", company='" + company + '\'' +
                ", location='" + location + '\'' +
                ", employmentType=" + employmentType +
                ", isActive=" + isActive +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Job job = (Job) o;
        return id != null && id.equals(job.id);
    }
    
    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
