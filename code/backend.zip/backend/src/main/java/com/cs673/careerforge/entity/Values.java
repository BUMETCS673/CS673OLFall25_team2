package com.cs673.careerforge.entity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Size;

/**
 * Embedded class representing company values.
 */
@Embeddable
public class Values {
    
    @Size(max = 200, message = "Values title must not exceed 200 characters")
    @Column(name = "values_title", length = 200)
    private String title;
    
    @Column(name = "values_list", columnDefinition = "TEXT")
    private String valuesList; // JSON string of values array
    
    // Constructors
    public Values() {}
    
    public Values(String title, String valuesList) {
        this.title = title;
        this.valuesList = valuesList;
    }
    
    // Getters and Setters
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getValuesList() {
        return valuesList;
    }
    
    public void setValuesList(String valuesList) {
        this.valuesList = valuesList;
    }
    
    @Override
    public String toString() {
        return "Values{" +
                "title='" + title + '\'' +
                ", valuesList='" + valuesList + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Values values = (Values) o;
        return java.util.Objects.equals(title, values.title) && 
               java.util.Objects.equals(valuesList, values.valuesList);
    }
    
    @Override
    public int hashCode() {
        return java.util.Objects.hash(title, valuesList);
    }
}
